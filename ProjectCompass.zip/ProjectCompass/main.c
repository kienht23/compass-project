#include "init.h"

#define true 1
#define false 0

uint8_t volatile state = false;
uint32_t volatile msTicks = 0;
uint32_t TICK_Green = 1000; // 1000ms = 1Hz
uint32_t TICK_Red = 500; // 500ms = 2Hz

int main() {
	init_LED();
	init_SW();
	init_ITR_SW();
	init_SysTick_interrupt() ;
	SegLCD_Init();
	
	reset_LED();
	
	while (1) {
		toggle_LED();
	}
	return 0;
}

//SW1 interrupt Handler
void PORTC_PORTD_IRQHandler(void) {
	//If SW1 not press => do nothing
	if ((PTC->PDIR & (1<<3)) != 0)
		return;
	
	//Toggle state System
	if (state == false) {
		PTD->PCOR |= 1 << 5;
		PTE->PSOR |= 1 << 29;
		state = true;
	}
	else {
		PTD->PSOR |= 1 << 5;
		PTE->PCOR |= 1 << 29;
		state = false;
	}

	/* Clear interrupt service flag in port control register otherwise int.remains active */
	PORTC->PCR[3] |= 1 << 24; // OR 		PORTC->PCR[3] |= PORT_PCR_ISF_MASK;
}

void toggle_LED() {
	if (state == false) {	
			PTE->PTOR |= 1 << 29;
			msTicks = 0;
			SegLCD_DisplayDecimal(msTicks);
			Delay(TICK_Red);
		} 
		else {
			PTD->PTOR |= 1 << 5;
			msTicks = 0;
			Delay(TICK_Green);
		}
}

void Delay(uint32_t TICK) {
	while (msTicks < TICK) {}; // Wait 500ms
	msTicks = 0; // Reset counter
}

// SysTick interrupt Handler
void SysTick_Handler() { 
	msTicks++; // Increment counter
}
